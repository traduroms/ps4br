===================
Ferramentas de PS4
===================

Eu fiz v�rias ferramentas, mas essas
tr�s s�o as mais �teis. Por isso resolvi
liberar.


Como usar:

- Nada mais simples, coloquei um arquivo
comprimido em lzss do pr�prio PS4 como
exemplo.

- O Ps4comp serve para comprimir um bloco
bin�rio de Ps4.

- O Ps4dec serve para descomprimir um bloco
lzss.

- O Ps4script serve para transformar um
bloco bin�rio descomprimido de PS4 em
um arquivo texto pronto para ser traduzido
ou alterado. Ele tamb�m faz o inverso.

- Com apenas essas tr�s ferramentas �
poss�vel alterar os di�logos de PS4. Mas
� preciso saber que o Ps4script s� funciona
na rom traduzida, pois j� est� com os acentos
incorporados nos gr�ficos.

- Para terem acesso ao texto do arquivo
block1br.lzss, descomprimam usando o Ps4dec.
Depois usem o Ps4script para criar o txt. Esse
txt pode ser alterado. Usando o mesmo
Ps4Script, pode-se criar um novo bin�rio a
partir do txt e recomprimi-lo com o Ps4comp.

OBS: Na rom PS4 existem v�rios blocos compri-
midos. � preciso ach�-los, extra�-los da rom
e depois usar essas ferramentas.

OBS2: Esse programa � espec�fico de PS4. N�o
fiz teste nenhum em outras roms, portanto, �
normal que s� funcione em PS4.

OBS3: Todos os programas devem ser usados na
linha de comando.


Hyllian.
